import React,{Component} from "react";


export default class Clothing extends Component
{


    render() {
        return(
            <h1>Clothing!!!!</h1>
        )
    }
}
