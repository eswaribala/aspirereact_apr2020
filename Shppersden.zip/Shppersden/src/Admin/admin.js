import React,{Component} from "react";


export default class Admin extends Component
{


    render() {
        return(
            <h1>Admin!!!!</h1>
        )
    }
}
