import React,{Component} from "react";
import Grid from "@material-ui/core/Grid";
import {TextField} from "@material-ui/core";
import Fab from "@material-ui/core/Fab";
import PersonIcon from '@material-ui/icons/Person'
import './registration.css'
import axios from 'axios'
export default class Registration extends Component
{
    constructor(props) {
        super(props);
        this.state={
            firstName:"",
            lastName:"",
            email:"",
            userName:"",
            password:"",
            errors: {},
            formSubmitted: false,

        }

    }

    validateForm() {
        const { firstName, lastName, email, userName, password } = this.state;
        let errors = {};
        let formIsValid = true;
        if (!firstName) {
            formIsValid = false;
            errors["firstNameErr"] = "*Please enter your first name.";
        }
        if (typeof firstName !== "undefined") {
            if (!(firstName.match(/^[a-zA-Z ]*$/))) {
                formIsValid = false;
                errors["firstNameErr"] = "*Please enter alphabet characters only.";
            }
        }

        if (!lastName) {
            formIsValid = false;
            errors["lastNameErr"] = "*Please enter your last name.";
        }
        if (typeof lastName !== "undefined") {
            if (!(lastName.match(/^[a-zA-Z ]*$/))) {
                formIsValid = false;
                errors["lastNameErr"] = "*Please enter alphabet characters only.";
            }
        }
        if (!email) {
            formIsValid = false;
            errors["emailErr"] = "*Please enter your email-ID.";
        }
        if (typeof email !== "undefined") {
            //regular expression for email validation
            var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            if (!pattern.test(email)) {
                formIsValid = false;
                errors["emailErr"] = "*Please enter valid email-ID.";
            }
        }
        if (!userName) {
            formIsValid = false;
            errors["userNameErr"] = "*Please enter your user name.";
        }
        if (typeof userName !== "undefined") {
            if (!(userName.match(/^[a-zA-Z ]*$/))) {
                formIsValid = false;
                errors["userNameErr"] = "*Please enter alphabet characters only.";
            }
        }
        if (!password) {
            formIsValid = false;
            errors["passwordErr"] = "*Please enter your password.";
        }
        if (typeof password !== "undefined") {
            if (!(password.match(/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/))) {
                formIsValid = false;
                errors["passwordErr"] = "*Please enter secure and strong password.";
            }
        }
        this.setState({
            errors: errors
        });
        return formIsValid;
    }

    handleChange = input => e => {
        console.log(e.target.value);
        this.setState({ [input]: e.target.value });
    };

    submit=(e)=>{
        e.preventDefault();
        console.log(this.state);
        this.setState({
            formSubmitted: true
        });

       if(this.validateForm()) {
           console.log(this.state);
          axios.post('https://blog-cf.cfapps.io/addboauser',
               this.state)
               .then(res => {
                   console.log(res.data)
                   //window.location.href="/Driver";
                   this.setState({
                       formSubmitted: false
                   });
               });


           this.setState({
               firstName:"",
               lastName:"",
               email:"",
               userName:"",
               password:"",
               errors: {},
               formSubmitted: false
           });
           console.log(this.state);
       }

    }


    render() {

        const { firstNameErr, emailErr, lastNameErr, userNameErr, passwordErr } = this.state.errors;
        return(
            <form onSubmit={this.submit} style={{ backgroundColor: '#F0F0F0' }} className="border border-primary shadow-none p-3 mb-5 bg-light rounded w-275" >
                <fieldset>
                    <legend>Add User</legend>
                    <Grid container spacing={2}>
                        <Grid item xs={12} sm={12}>
                            <TextField
                                id="firstName"
                                label="First Name"
                                margin="normal"
                                fullWidth
                                onChange={this.handleChange("firstName")}
                                className={firstNameErr ? ' showError' : ''}
                            />
                            {firstNameErr &&
                            <div style={{ color: "red", paddingBottom: 10 }}>
                                {firstNameErr}</div>
                            }

                        </Grid>
                        <Grid item xs={12} sm={12}>
                            <TextField
                                id="lastName"
                                label="Last Name"
                                margin="normal"
                                fullWidth
                                onChange={this.handleChange("lastName")}
                                className={lastNameErr ? ' showError' : ''}
                            />
                            {lastNameErr &&
                            <div style={{ color: "red", paddingBottom: 10 }}>
                                {lastNameErr}</div>
                            }
                        </Grid>
                        <Grid item xs={12} sm={12}>
                            <TextField
                                id="email"
                                label="Email"
                                margin="normal"
                                fullWidth
                                onChange={this.handleChange("email")}
                                className={emailErr ? ' showError' : ''}
                            />
                            {emailErr &&
                            <div style={{ color: "red", paddingBottom: 10 }}>
                                {emailErr}</div>
                            }
                        </Grid>
                        <Grid item xs={12} sm={12}>
                            <TextField
                                id="userName"
                                label="User Name"
                                margin="normal"
                                fullWidth
                                onChange={this.handleChange("userName")}
                                className={userNameErr ? ' showError' : ''}
                            />
                            {userNameErr &&
                            <div style={{ color: "red", paddingBottom: 10 }}>
                                {userNameErr}</div>
                            }
                        </Grid>
                        <Grid item xs={12} sm={12}>
                            <TextField
                                id="password"
                                label="Password"
                                margin="normal"
                                fullWidth
                                onChange={this.handleChange("password")}
                                className={passwordErr ? ' showError' : ''}
                            />
                            {passwordErr &&
                            <div style={{ color: "red", paddingBottom: 10 }}>
                                {passwordErr}</div>
                            }
                        </Grid>
                    </Grid>
                    <div className="d-flex justify-content-center mt-5">
                    <Fab color="primary" aria-label="add"  type="submit" style={{marginRight:50}} >
                        <PersonIcon />
                    </Fab>

                        <Fab color="secondary" aria-label="add"  type="reset" >
                            <PersonIcon />
                        </Fab>
                    </div>
                </fieldset>

            </form>
        )
    }
}
