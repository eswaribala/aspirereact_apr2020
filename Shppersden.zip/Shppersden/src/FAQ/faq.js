import React,{Component} from "react";


export default class FAQ extends Component
{


    render() {
        return(
            <h1>FAQ!!!!</h1>
        )
    }
}
