import React,{Component} from "react";


export default class Sports extends Component
{


    render() {
        return(
            <h1>Sports!!!!</h1>
        )
    }
}
