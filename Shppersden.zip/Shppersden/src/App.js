import React, {Component} from 'react';
import './App.css';
import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import ShoppersLogo from "./Logo/logo";
import ShoppersMenu from "./Menu/menu";
import TopMenu from "./TopMenu/topmenu";
//import {TopTabs} from "./TopMenu/topmenu";
import Category from './Search/search'
//Stateful component
export class App extends Component
{
    //poc life cycle components are accessible

    constructor() {
        super();
        console.log("App Constructor");
        this.state={
            currentTime:new Date(),
            //props
            menuItems:[{
                id:1,
                name:'Books',
                path:'#/Books'
            },
                {
                    id:2,
                    name:'Gift',
                    path:'#/Gift'
                },
                {
                    id:3,
                    name:'Clothing',
                    path:'#/Clothing'
                },
                {
                    id:4,
                    name:'Sports',
                    path:'#/Sports'
                },

            ],

            topMenu: [
                {label: 'Home', icon: 'pi pi-fw pi-home', command: () => { window.location.hash = "/Home" }},
                {label: 'Admin', icon: 'pi pi-fw pi-calendar', command: () => { window.location.hash  = "/Admin" }},
                {label: 'Accounts', icon: 'pi pi-fw pi-user', command: () => { window.location.hash  = "/Accounts" }},
                {label: 'FAQ', icon: 'pi pi-fw pi-file', command: () => { window.location.hash  = "/FAQ" }},
                {label: 'Aboutus', icon: 'pi pi-fw pi-cog', command: () => { window.location.hash  = "/Aboutus" }},
                {label: 'Help', icon: 'pi pi-fw pi-question', command: () => { window.location.hash  = "/Help" }},
            ]

        }
    }

    tick()
    {
        //update the state
        this.setState({
            currentTime:new Date()
        })
    }




    componentDidMount() {
        //super.componentDidMount();
        console.log("App Component did mount");
        setInterval(()=>this.tick(),1000)

    }

    render() {
        return (
            <div >
               <header className="App-header">
                   <ShoppersLogo/>
                   <h1 className="multicolortext">SHOPPERS DEN</h1>
                   <h6 className="timer">{this.state.currentTime.toLocaleTimeString()}</h6>
               </header>

                <Category/>
                <section className="top">
                 <TopMenu items={this.state.topMenu}/>

                </section>
                <ShoppersMenu items={this.state.menuItems} />


            </div>
        );
    }
}


