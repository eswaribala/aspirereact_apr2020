import React,{Component} from "react";


export default class Gift extends Component
{


    render() {
        return(
            <h1>Gift!!!!</h1>
        )
    }
}
