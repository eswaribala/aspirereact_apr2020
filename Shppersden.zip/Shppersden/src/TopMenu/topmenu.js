import React, {useState, Component} from 'react';
import {TabMenu} from 'primereact/tabmenu';
import {HashRouter,Switch,Route} from 'react-router-dom'
import './topmenu.css'
import Home from "../Home/home";
import Admin from "../Admin/admin";
import Accounts from "../Accounts/accounts";
import FAQ from "../FAQ/faq";
import Aboutus from "../Aboutus/aboutus";
import Help from "../Help/help";
//import {Tabs} from "react-bootstrap";
//import {Tab} from "react-bootstrap";
/*
export function TopTabs() {
//react hook
    const [key, setKey] = useState('home');


    return (
        <Tabs
            id="controlled-tab-example"
            activeKey={key}
            onSelect={(k) => setKey(k)} className="tab-menu">
            <Tab eventKey="home" title="Home" >
                <Home/>
            </Tab>
            <Tab eventKey="admin" title="Admin">
                <Accounts />
            </Tab>
            <Tab eventKey="Accounts" title="Accounts" >
                <Accounts />
            </Tab>
            <Tab eventKey="FAQ" title="FAQ" >
                <FAQ />
            </Tab>
            <Tab eventKey="Aboutus" title="About us" >
                <Aboutus />
            </Tab>
            <Tab eventKey="Help" title="Help" >
                <Help />
            </Tab>
        </Tabs>
    );
}
*/


export default class TopMenu extends Component {
    constructor(props) {
        super(props);
        this.state={
            menuItems:this.props.items,

        }
    }
    render() {

        return (
            <HashRouter>
            <div className="container">
                <nav className="navbar navbar-expand-lg navbar-dark bg-light ">
                    <div className="content-section implementation">
                        <TabMenu model={this.state.menuItems} activeItem={this.state.activeItem}
                                 onTabChange={(e) => this.setState({activeItem: e.value})}/>
                    </div>
                </nav>
            </div>
            <Switch>
                <Route path='/Home' component={Home}/>
                <Route path='/Admin' component={Admin}/>
                <Route path='/Accounts' component={Accounts}/>
                <Route path='/Aboutus' component={Aboutus}/>
                <Route path='/Help' component={Help}/>
                <Route path='/FAQ' component={FAQ}/>
            </Switch>
            </HashRouter>


        );
    }
}
