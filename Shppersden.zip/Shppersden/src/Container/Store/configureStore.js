
import {applyMiddleware, createStore,compose} from "redux";
import rootReducer from "../Reducer/index";
import {forbiddenWordsMiddleware} from "../Middleware";
import thunk from "redux-thunk";
//Step2
// createStore takes a reducer as the first argument
const storeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const configureStore = createStore(
    rootReducer,
    storeEnhancers(applyMiddleware(forbiddenWordsMiddleware, thunk))
);
export default configureStore;
