import { ADD_BOOK} from "../Constant/action-types";
import axios from 'axios';

const apiUrl = 'http://localhost:4000/books';
/*export function addBook(payload) {
    console.log(payload);
    return { type: ADD_BOOK, payload };
}*/


export const addBook = (book) => {
    return (dispatch) => {
        return axios.post(`${apiUrl}/add`,book)
            .then(response => {
                dispatch(addBookSuccess(response.data))
            })
            .catch(error => {
                throw(error);
            });
    };
};

export const addBookSuccess=  (payload) => {
    console.log(payload);
    return { type: ADD_BOOK, payload };
};
