import * as actionTypes from '../Constant/action-types'
import {ADD_BOOK} from "../Constant/action-types";
const initialState = {
    books: []
};
//current state of the object
function rootReducer(state = initialState, action) {
    if (action.type === ADD_BOOK) {
        console.log()
        return Object.assign({}, state, {
            books: state.books.concat(action.payload)
        });
    }
    return state;
}
export default rootReducer;
