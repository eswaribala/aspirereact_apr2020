import React from "react";
import { makeStyles } from '@material-ui/core/styles';
import { connect } from "react-redux";
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import './book.css'
const mapStateToProps = state => {
    console.log(state);
    return { books: state.books };
};



const ConnectedList = ({ books }) => (
 /*   <ul>
        {books.map(el => (
            <li key={el.title}>{el.title}======>{el.author}</li>

        ))}
    </ul>*/

    <div className="table border border-primary shadow-none p-3 mb-5 bg-light rounded ">
    <TableContainer component={Paper}   aria-label="Books List">

        <Table style={{ backgroundColor: '#F0F0F0' }} >
            <TableHead>
                <TableRow>
                    <TableCell>Title</TableCell>
                    <TableCell>Author</TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {books.map((book) => (
                    <TableRow key={book.title}>
                        <TableCell component="th" scope="row">
                            {book.title}
                        </TableCell>
                        <TableCell >{book.author}</TableCell>

                    </TableRow>
                ))}
            </TableBody>
        </Table>
    </TableContainer>
    </div>
);

//starting point
const BookList = connect(mapStateToProps)(ConnectedList);

export default BookList;
