import React,{Component} from "react";
import Grid from "@material-ui/core/Grid";
import {TextField} from "@material-ui/core";
import Fab from "@material-ui/core/Fab";
import PersonIcon from '@material-ui/icons/Person'
import {addBook} from "../Container/Action";
import './book.css'
import axios from 'axios'
import { connect } from 'react-redux';
import BookList from "./booklist";

class Book extends Component
{
    constructor(props) {
        super(props);
        this.state={
            title:"",
            author:""

        }

    }



    handleChange = input => e => {
        console.log(e.target.value);
        this.setState({ [input]: e.target.value });
    };

    submit=(e)=>{
        e.preventDefault();
        console.log(this.state);

      //trigger action

        const { title,author } = this.state;
        this.props.addBook({ title,author });
        this.setState({
                title:"",
                author:""
            });

    }


    render() {


        return(
            <div className="content">

            <form onSubmit={this.submit} style={{ backgroundColor: '#F0F0F0' }} className="bookform border border-primary shadow-none p-3 mb-5 bg-light rounded " >
                <fieldset>
                    <legend>Add Book</legend>
                    <Grid container spacing={2}>
                        <Grid item xs={12} sm={12}>
                            <TextField
                                id="title"
                                label="Tilte"
                                margin="normal"
                                fullWidth
                                onChange={this.handleChange("title")}

                            />

                        </Grid>
                        <Grid item xs={12} sm={12}>
                            <TextField
                                id="author"
                                label="Author"
                                margin="normal"
                                fullWidth
                                onChange={this.handleChange("author")}

                            />

                        </Grid>

                    </Grid>
                    <div className="d-flex justify-content-center mt-5">
                        <Fab color="primary" aria-label="add"  type="submit" style={{marginRight:50}} >
                            <PersonIcon />
                        </Fab>

                        <Fab color="secondary" aria-label="add"  type="reset" >
                            <PersonIcon />
                        </Fab>
                    </div>
                </fieldset>

            </form>

                   <BookList/>

            </div>

            )
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        books: state.books
    }
};
const mapDispatchToProps = (dispatch) => {
    return {
        addBook: book=> dispatch(addBook(book)),

    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Book);
