import React,{Component} from "react";


export default class Aboutus extends Component
{


    render() {
        return(
            <h1>About us!!!!</h1>
        )
    }
}
