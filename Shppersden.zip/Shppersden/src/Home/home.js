import React,{Component} from "react";
import Card from "react-bootstrap/Card";
import {Button} from "react-bootstrap";
import logoPath from '../assets/images/logo.png'
import axios from 'axios'
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import './home.css'
const apiUrl='https://jsonplaceholder.typicode.com/photos';

export default class Home extends Component
{

    constructor(props) {
        super(props);
        this.state={
            photos:[]
        }
    }
    componentDidMount() {
        axios.get(`${apiUrl}`)
            .then(response => {
                   let images=response.data.slice(1,15);
                    console.log(images);
                    this.setState({
                        photos: images
                    })
                }
            )
            .catch(error => {
                throw(error);
            });
    }

    render() {

         return(
             <Grid container spacing={2}>
                 {
                     this.state.photos.map((photo, i) => (
                         <Grid item xs={3} key={i} >
                         <Card className="card">
                             <Card.Img src={photo.thumbnailUrl}/>
                             <Card.Body>


                                 <Button variant="primary">View</Button>
                             </Card.Body>
                         </Card>
                         </Grid>
                     ))
                 }
             </Grid>

         )
    }
}
