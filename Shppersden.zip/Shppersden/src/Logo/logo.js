import React from "react";
import logoPath from '../assets/images/shopper.jpg'
import  './logo.css'

//stateless component
const shoppersLogo=()=>(
    <img src={logoPath} alt="logo" className='logo'/>
);

export default shoppersLogo;
