import React,{Component} from "react";
import {Dropdown} from "react-bootstrap";
import axios from 'axios';
import './search.css'
const apiUrl = 'https://raw.githubusercontent.com/eswaribala/aspirereact_apr2020/master/clothing.json';
export default class Category extends Component
{

    constructor(props) {
        super(props);
        this.state={
           categories:[]
        }
    }


    componentDidMount() {
        axios.get(`${apiUrl}`)
            .then(response => {
                    console.log(response.data);
                    this.setState({
                        categories: response.data.clothes
                    })
                }
            )
            .catch(error => {
                throw(error);
            });
    }


    render() {
        return(
            <Dropdown className="drop-down">
                <Dropdown.Toggle  id="dropdown-basic">
                    Category
                </Dropdown.Toggle>
                <Dropdown.Menu className="drop-down-menu" >
                    {
                        this.state.categories.map((category,i)=>(
                                <Dropdown.Item key={i} href="#/action-1">{category}</Dropdown.Item>

                            )
                        )
                    }
                </Dropdown.Menu>
            </Dropdown>
        )
    }
}
