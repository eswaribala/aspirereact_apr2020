import React from "react";
import './menu.css'
import {BrowserRouter, Switch, Route, HashRouter} from 'react-router-dom'
import { useHistory } from 'react-router-dom';
import Book from "../Book/book";
import Clothing from "../Clothing/clothing";
import Sports from "../Sports/sports";
import Gift from "../Gift/gift";
import Link from "@material-ui/core/Link";
import Button from "@material-ui/core/Button";

//two components are communicating with each other,
// relationship between state and props
//stateless component
export const shoppersMenu =(props)=>(

    <HashRouter basename={"/shoppersden"}>
    <div className="tab">
        {
             props.items.map(item=>(
                 <button  key={item.id} onClick={()=>{ window.location.hash=item.path}}>
                 {item.name}
                 </button>
             ))
        }
    </div>
    <Switch>
        <Route>
            <Route path='/Books' component={Book}/>
            <Route path='/Clothing' component={Clothing}/>
            <Route path='/Sports' component={Sports}/>
            <Route path='/Gift' component={Gift}/>

        </Route>
    </Switch>
    </HashRouter>
);

export default  shoppersMenu;
