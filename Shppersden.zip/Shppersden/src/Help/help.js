import React,{Component} from "react";


export default class Help extends Component
{


    render() {
        return(
            <h1>Help!!!!</h1>
        )
    }
}
